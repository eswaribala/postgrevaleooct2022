DROP TRIGGER trgCheckOrderMail ON orders;
DROP FUNCTION checkordermail();
DROP TABLE orders;
